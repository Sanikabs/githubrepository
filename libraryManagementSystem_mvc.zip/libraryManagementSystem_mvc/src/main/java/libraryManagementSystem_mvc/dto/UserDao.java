package libraryManagementSystem_mvc.dto;

import java.util.List;



import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

@Component
public class UserDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("vikas");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	public Users saveUser(Users users) {
		entityTransaction.begin();
		entityManager.persist(users);
		entityTransaction.commit();
		return users;

	}

	public List<Users> getAllUsers() {
		Query query = entityManager.createQuery("select u from Users u");
		List<Users> userList = query.getResultList();
		return userList;
	}

}
