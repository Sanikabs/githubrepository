package libraryManagementSystem_mvc.dto;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Controller
public class LibararyManagementController {

	  @Autowired
		UserDao userDao;
	  @Autowired
      Users users;
     
	

	@GetMapping("/save")
public Users saveUsers(HttpServletRequest request,HttpServletResponse response) {
          String name=  request.getParameter("name");
                         users.setName(name);
            return userDao.saveUser(users);
}
	     
	     @GetMapping("/getUser")
	      public List<Users> getListofUsers(HttpServletRequest request,HttpServletResponse response){
	    	 request.setAttribute("users",userDao.getAllUsers());
	    	   return  userDao.getAllUsers();
	      }
	     
	     
}
